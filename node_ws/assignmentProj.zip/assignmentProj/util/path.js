//const express = require('express');

const path = require('path');

module.exports = path.dirname(require.main.filename);