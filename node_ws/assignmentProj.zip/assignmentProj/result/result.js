const express = require('express');
const path = require('path');
const rootDir = require('../util/path')

const router = express.Router();
router.use(express.static(path.join(__dirname,'public')));
router.use('/result',(req,res)=>{

   
    console.log('/result');
    console.log(req.body);
    return res.sendFile(path.join(rootDir,'views','result.html'));
});

module.exports = router;